`root/img`
